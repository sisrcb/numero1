package com.example.lensysapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
